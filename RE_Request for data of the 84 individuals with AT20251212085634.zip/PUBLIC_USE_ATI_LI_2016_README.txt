################################################################################
# FILENAME:        PUBLIC_USE_ATI_LI_2016_README.txt
# 
# PURPOSE:         To desribe the 2 public use files/datasets:
#                  - public_use_ati_li_2016_demo_vir
#                  - public_use_ati_li_2016_long_rna
# 
# AUTHOR:          Evgenia (Tzeni) Aga, Ronald Bosch
#
# CREATION DATE:   10DEC2025
# 
# NOTES:           none
# MODIFICATIONS:   none
################################################################################

 
INTRODUCTION
These datasets contain data for the N = 235 participants from 6 ACTG studies with Analytic Treatment Interruption (ATI), who were on 
suppressive antiretroviral treatment (ART), received no immunologic interventions, and had HIV-1 RNA level < 50 copies/mL at time of ATI.
As described in the primary paper (Li 2016), the 6 source studies are: ACTG 371, A5024, A5068, A5170, A5187, A5197.
Note that HIV-1 RNA levels during ATI were measured less frequently in A5170 (every 4 weeks) than in the other studies.
If exclude A5170, the remaining N = 139 participants were in studies where HIV-1 RNA levels were to be measured every 1-2 weeks initially during ATI.

N = 124 participants (of the 235) had HIV-persistence data measured prior to ART interruption. These data were examined in Li 2016 
and also in multiple statistical methods and modeling papers (Conway 2019, Wang 2020, Lok 2021, Chernofsky 2024, Chernofsky 2025), 
including causal mediation analysis for the effects of pre-ATI HIV-persistence measures on ATI outcomes.


DATASETS
1.  public_use_ati_li_2016_demo_vir
This dataset has one observation per participant (N = 235 records), and includes participant characteristics and HIV-persistence measurements
obtained prior to ART treatment interruption (cell-associated HIV DNA, cell-associated HIV RNA, single copy assay (SCA) HIV RNA). 
Note that SCA is available for 94 participants. 
In addition, variables are provided for the source ACTG study, whether participant started ART during acute/early or chronic infection,
ART duration, whether the pre-ATI regimen was NNRTI-based, nadir CD4, pre-ATI CD4, pre-ART HIV-1 RNA level, pre-ATI HIV-1 RNA level.

2. public_use_ati_li_2016_long_rna
This dataset has all the longitudinal HIV RNA measurements during the ATI (i.e., after stopping ART).
Note that the HIV RNA measurement schedule differed across the five source studies, as described in Chernofsky 2025, with the least frequent
schedule in A5170 (every 4 weeks), which should be considered in any analysis. For example, Chernofsky 2025 applied interval censored data methods.


RELEVANT PAPERS
Li JZ, Etemad B, Ahmed H, Aga E, Bosch RJ, Mellors JW, Kuritzkes DR, Lederman MM, Para M, Gandhi RT.
The size of the expressed HIV reservoir predicts timing of viral rebound after treatment interruption.
AIDS. 2016 Jan 28;30(3):343-53.
https://pubmed.ncbi.nlm.nih.gov/26588174/

Conway JM, Perelson AS, Li JZ.
Predictions of time to HIV viral rebound following ART suspension that incorporate personal biomarkers. 
PLoS Comput Biol 2019 July 24; 15(7), e1007229. 
https://pubmed.ncbi.nlm.nih.gov/31339888/

Wang R, Bing A, Wang C, Hu Y, Bosch RJ, DeGruttola V. 
A flexible nonlinear mixed effects model for HIV viral load rebound after treatment interruption. 
Stat Med, 2020; 39:2051-2066.
https://pubmed.ncbi.nlm.nih.gov/32293756/

Lok JJ, Bosch RJ. 
Causal organic indirect and direct effects: Closer to the original approach to mediation analysis, with a product method for binary mediators.
Epidemiology. 2021; 32(3):412-420.
https://pubmed.ncbi.nlm.nih.gov/33783395/

Chernofsky A, Bosch RJ, Lok JJ.
Causal mediation analysis with mediator values below an assay limit.
Stat Med. 2024 May 30;43(12):2299-2313
https://pubmed.ncbi.nlm.nih.gov/38556761/

Chernofsky A, Lok JJ.
Causal mediation analysis for time-to-event outcomes on the Restricted Mean Survival Time scale: A pseudo-value approach.
PLoS One. 2025 Apr 9;20(4):e0319074.
https://pubmed.ncbi.nlm.nih.gov/40203275/



